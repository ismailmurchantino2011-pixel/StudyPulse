/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "eb2f47d7aba5bbc648cf6b072ed7d8a6"
  }, {
    "url": "pwa-512x512.png",
    "revision": "eb2f47d7aba5bbc648cf6b072ed7d8a6"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a42d1c47a9f65e4fc5630e45deb6b2e7"
  }, {
    "url": "index.html",
    "revision": "f8860504d5179a57bca51e56c0405f60"
  }, {
    "url": "icon.svg",
    "revision": "6793c7196b0b6fc76c92428312abd765"
  }, {
    "url": "favicon.ico",
    "revision": "b9944979679371aaf84b02cf245566dd"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c2380f132733e164ac43a00c144f140e"
  }, {
    "url": "assets/index-BsTJ9Tfs.js",
    "revision": null
  }, {
    "url": "assets/index-BRDkKxyR.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c2380f132733e164ac43a00c144f140e"
  }, {
    "url": "favicon.ico",
    "revision": "b9944979679371aaf84b02cf245566dd"
  }, {
    "url": "icon.svg",
    "revision": "6793c7196b0b6fc76c92428312abd765"
  }, {
    "url": "pwa-192x192.png",
    "revision": "a42d1c47a9f65e4fc5630e45deb6b2e7"
  }, {
    "url": "pwa-512x512.png",
    "revision": "eb2f47d7aba5bbc648cf6b072ed7d8a6"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "eb2f47d7aba5bbc648cf6b072ed7d8a6"
  }, {
    "url": "manifest.webmanifest",
    "revision": "7b4ce5a9db99a79c7b6dc30e62f78342"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
