import os
import zipfile

exclude_dirs = {'node_modules', '.git', 'dist', 'coverage', '.cache', 'dev-dist'}
exclude_files = {'.DS_Store'}

out_path = 'public/studypulse-source-code.zip'
os.makedirs('public', exist_ok=True)

with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file in exclude_files or file.endswith('.zip') or file.endswith('.log'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)

print(f"Archive successfully created: {out_path} ({os.path.getsize(out_path)} bytes)")
